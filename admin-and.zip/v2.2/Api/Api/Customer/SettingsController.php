<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Facades\Hash;
use Auth;


class SettingsController extends Controller
{
	public function update(Request $request)
	{
		$user = Auth::User();
		$validator = \Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'unique:users,email,' . $user->id,
        ]);

        if($validator->fails())
        {
            return response()->json(['error'=>$validator->errors()->all()[0]]);
        }

        
        $user->email = $request->email;
        $user->name = $request->name;
        $user->save();

        if($request->current_password)
        {
        	$validator = \Validator::make($request->all(), [
	            'current_password' => 'required|password',
            	'password' => 'required|confirmed'
	        ]);

	        if($validator->fails())
	        {
	            return response()->json(['error'=>$validator->errors()->all()[0]]);
	        }

	        $user->password = Hash::make($request->password);
	        $user->save();

	        return $user;
            
        }
        return $user;
	}
}
